/* arreglo de objetpo de Clientes y su nivel de riesgo */
let clientes = [
     {
         "dni": "1-9",
         "nombre": "Jose Peralta Luna",
         "nivelRiesgo": 4
     },
     {
         "dni": "2-7",
         "nombre": "Ricardo Zamorano Solis",
         "nivelRiesgo": 3
     },
     {
         "dni": "3-5",
         "nombre": "Walter Smith Wason",
         "nivelRiesgo": 1
     },
     {
         "dni": "4-3",
         "nombre": "Luis Ernesto Aravalos Gomez",
         "nivelRiesgo": 2
     },
     {
          "dni": "5-1",
          "nombre": "Carlos Aravena Montiel",
          "nivelRiesgo": 5
      }
 
   ]

/* arreglo con tasas de interes segun el numero de cuotas (periodicidad) solicitadas */
const tasas = [{cuoMenIguQue:  6, interes: 2.1 },
               {cuoMenIguQue: 12, interes: 1.8 },
               {cuoMenIguQue: 24, interes: 1.5 },
               {cuoMenIguQue: 36, interes: 1.2 },
               {cuoMenIguQue: 48, interes: 1.0 },
               {cuoMenIguQue: 60, interes: 0.9 },
               {cuoMenIguQue: 66, interes: 0.8 }
   ];

const cuotasPermitidas = tasas.map(function(tasas) {
     return tasas.cuoMenIguQue;
});

/* arreglo con las acciones a realizar sobre arreglo de tasas 
   cuando parte por primera vez el programa */
const accionEnTasas = [
     { accion: "E", numCuota: "60", valTasa: 0.9 },
     { accion: "I", numCuota: "72", valTasa: 0.7 }
];
   
/* arreglo con las acciones a realizar sobre arreglo de tasas para dejarlo
   en el Local Storage, con valores distintos a la modificacion original
   para poder notar la diferencia entre tomarlo al principio del programa
   o tomarlo del Local Storage */
const accionEnTasasAStorage = [
     { accion: "E", numCuota: "66", valTasa: 0.8 },
     { accion: "I", numCuota: "80", valTasa: 0.6 }
];

/* arreglo limetes de monto a otorgar segun nivel de riesgo del cliente  */
const mtoLimite = [{glsRiesgo: "Cliente sin Riesgo",        nivelRiesgo: "1", mtoMaxi: 9999999999 },
                   {glsRiesgo: "Cliente poco Riesgoso",     nivelRiesgo: "2", mtoMaxi: 20000000},
                   {glsRiesgo: "Cliente Riesgo intermedio", nivelRiesgo: "3", mtoMaxi: 5000000},
                   {glsRiesgo: "Cliente Riesgoso",          nivelRiesgo: "4", mtoMaxi: 1000000},
                   {glsRiesgo: "Cliente muy Riesgoso",      nivelRiesgo: "5", mtoMaxi: 0}
];

// Funcion para desplegar los clientes que pueden pedir prestamos
function desplegarClientes(){
     cargaCltDis = document.querySelector('#tabla-cliente tbody');
     while(cargaCltDis.firstChild){
          cargaCltDis.removeChild(cargaCltDis.firstChild);
     }
     for(let i = 0; i <= 4; i++) {
       
       const fila = document.createElement("tr");
       fila.innerHTML = `
            <td>${i}</td>
            <td>${clientes[i].dni}</td>
            <td>${clientes[i].nombre}</td>
            <td>${clientes[i].nivelRiesgo}</td>
       `;
       cargaCltDis.appendChild(fila)
     }  
}


// Funcion para desplegar los clientes que pueden pedir prestamos
function desplegarIntXCuo(){
     cargaCuoDis = document.querySelector('#tabla-cuotas tbody');
     while(cargaCuoDis.firstChild){
          cargaCuoDis.removeChild(cargaCuoDis.firstChild);
     }
     for(let i = 0; i <= 6; i++) {
       
       const fila1 = document.createElement("tr");
       fila1.innerHTML = `
            <td>${i}</td>
            <td>${tasas[i].cuoMenIguQue}</td>
            <td>${tasas[i].interes}</td>
       `;
       cargaCuoDis.appendChild(fila1)
     }  
}


// Funcion para validar la existencia del cliente y obtener el nivel de riesgo del cliente
function obtCliente(dniCliente){
     let cliente = clientes.find(cliente => cliente.dni === dniCliente);
     if (cliente == null) {
          alert("Cliente no existe");
          return 0;
     }else {
          this.dniObtClte = cliente.dni;
          this.nombreObtClte = cliente.nombre;
          this.riesgoObtClte = cliente.nivelRiesgo;
          return riesgoObtClte;
     }


}


/* funcion que captura los datos del formulario */
function capturaClte(){
   
         var dniRutCliente=document.getElementById("clteDniRut").value;
         var mtoPresCliente=document.getElementById("mtoPrestamo").value;
         var numCuoCliente=document.getElementById("numCuotas").value;
         if(dniRutCliente==""){
           alert("El DNI o RUT es obligarorio");
           document.getElementById("clteDniRut").focus();
         }else{
           const nivelRiesgoCliente = obtCliente(dniRutCliente)
           
           if(nivelRiesgoCliente == 0){
               document.getElementById("clteDniRut").focus();
           }else {
             if(mtoPresCliente==""){
               alert("El monto del prestamo es obligatorio");
               document.getElementById("mtoPrestamo").focus();
             }else{
               const mtoMaxPrestamo = riesgo(riesgoObtClte)
               if (mtoPresCliente > mtoMaxPrestamo) {
                    alert(`
                     Monto solicitado excede mto maximo segun nivel de Riesgo
                     ====================================================
                         Esta solicitando                    : ${mtoPresCliente}
                         y el Monto Maximo de Prestamo es de : ${mtoMaxPrestamo}
                         Nivel de Riesgo del cliente es      : ${riesgoObtClte}
                    `);
                    document.getElementById("mtoPrestamo").focus();
               } else {
                    if(numCuoCliente==""){
                         alert("El numero de cuotas es obligatorio");
                         document.getElementById("numCuotas").focus();
                   }else{
                      const [numCuotas, interesXNumCuota] = obtieneInteres(numCuoCliente)
                      if (numCuotas > 0){
                         cargaCalculos = document.querySelector('#tabla-calculos tbody');
                         const valorCuotaF = calcValorCuota(mtoPresCliente, numCuotas, interesXNumCuota)
/*                       aqui deberiamos limpiar el Local Storage despues de generar las cuotas 
                         localStorage.clear();
*/

                      }
 
                   }
                        

           }
          }
     }
          
   }
   
   

// Funcion para validar el nivel de riego del cliente
// y recuperar el monto maximo de prestamo segun nivel de riesgo del cliente
function riesgo(nivelRiesgo){
     const mtoPrestamo = mtoLimite.find((item) => item.nivelRiesgo === nivelRiesgo.toString());
 
     if (mtoPrestamo) {
          return mtoPrestamo.mtoMaxi
     } else {
          alert("Nivel de Riesgo Invalido");
          return 0;
     }
}

// Funcion para validar el numero de cuotas ingresado y
// y recuoperar el interes a a aplicar de acuerdo a la cantidad de meses solicitados
function obtieneInteres(numCuotas){

          const ptjInteres = tasas.find((item) => item.cuoMenIguQue == numCuotas);
    
          if (ptjInteres) {
                    return [numCuotas, ptjInteres.interes];
          } else {   
                    alert(`
                         Numero de cuotas no permitido
                         =============================
                         Cantidad de Cuotas Solicitada         : ${numCuotas}
                         solo se aceptan las siguentes Cuotas  : ${cuotasPermitidas}
                    `);
                    document.getElementById("numCuotas").focus();
                 }
     }
     }
//}

// Funcion para calcular el valor de la cuota
function calcValorCuota(monto, cuotas, intereses) {

     while(cargaCalculos.firstChild){
          cargaCalculos.removeChild(cargaCalculos.firstChild);
      }

     valorCuota = monto * (Math.pow(1+intereses/100, cuotas)*intereses/100)/(Math.pow(1+intereses/100, cuotas)-1);

     for(let i = 1; i <= cuotas; i++) {
          valorIntCuota = parseFloat(monto*(intereses/100));
          valorCapResto = valorCuota - valorIntCuota;
          monto = parseFloat(monto-valorCapResto);

          const fila = document.createElement("tr");
          fila.innerHTML = `
               <td>${i}</td>
               <td>${valorCuota.toFixed(2)}</td>
               <td>${valorCapResto.toFixed(2)}</td>
               <td>${valorIntCuota.toFixed(2)}</td>
               <td>${monto.toFixed(2)}</td>
          `;
          cargaCalculos.appendChild(fila)

     }

     return valorCuota
}

function modificarTasas(){
/* agregamos una nueva tasa al final del arreglo de tasa*/
     let nuevaLongitud = tasas.push({cuoMenIguQue: 72, interes: 0.7});
     console.log(tasas.length);
     tasas.forEach(function (elemento, indice, array) {
          console.log(elemento, indice);
     });

/* eliminamos la tasa a 60 meses en el arreglo */
     const indice = tasas.findIndex((elemento, indice) => {
          if (elemento.cuoMenIguQue === 60) {
               return true;
           }
     });
     var newTasas = tasas.splice(indice, 1);
}

let nivelRiesgo      = 0;
let numCuotas        = 0;
let mtoPrestamoSol   = 0;
let mtoMaxPrestamo   = [];
let interesXNumCuota = [];

/*desplegaos arreglo de Clientes y arreglo de Tasas */
const desplegaCliente = desplegarClientes()
const desplegaIntXCuo = desplegarIntXCuo()

let accionEnTasasStg;
// traemos las tasas del storage

 let tasaStorage = localStorage.getItem("tasas");

if (tasaStorage) {
// actualizamos los datos en el arreglo de tasas a partir del arreglo recuperado del storage
  accionEnTasasStg = JSON.parse(tasaStorage);
  let div = document.createElement("div");
  div.innerHTML = "Tasas encontrado";
  document.body.append(div);
  const modificaTasas = modificarTasas()
} else {
// actualizamos los datos en el arreglo de tasas a partir del arreglo accionEnTasas  
  let div = document.createElement("div");
  div.innerHTML = "no se encontro tasas";
  document.body.append(div);
  const modificaTasas = modificarTasas()
/* almacenamos en local storage las acciones sobre arreglo de tasas */
  localStorage.setItem("tasas", JSON.stringify(accionEnTasasAStorage));
}
/* lo dejo lara limpiar el Local Storag mientras se prueba
//-->localStorage.clear();
*/

document.getElementById("clteDniRut").focus();